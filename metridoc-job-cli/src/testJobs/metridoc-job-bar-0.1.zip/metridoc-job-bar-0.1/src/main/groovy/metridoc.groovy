println "bar has run"
println "bar has args $args"
return "bar has run"