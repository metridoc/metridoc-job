println "bar has run"
return "bar has run"